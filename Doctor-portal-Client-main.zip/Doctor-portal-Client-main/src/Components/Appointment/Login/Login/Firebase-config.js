const firebaseConfig = {
    apiKey: "AIzaSyDCaQJFtwIegFSzkQRuJXjdWi1jvgraypU",
    authDomain: "doctor-portal-401b3.firebaseapp.com",
    projectId: "doctor-portal-401b3",
    storageBucket: "doctor-portal-401b3.appspot.com",
    messagingSenderId: "1095531975651",
    appId: "1:1095531975651:web:e3a07d385b0b77c1e246d6"
  };
  export default firebaseConfig;
  
