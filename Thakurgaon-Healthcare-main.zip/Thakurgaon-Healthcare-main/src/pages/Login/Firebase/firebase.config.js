
const firebaseConfig = {
  apiKey: "AIzaSyCODiI9KlFYi9Zy5DulVGkuJmcRiuOu8ck",
  authDomain: "thakurgaon-hospital.firebaseapp.com",
  projectId: "thakurgaon-hospital",
  storageBucket: "thakurgaon-hospital.appspot.com",
  messagingSenderId: "1037857498957",
  appId: "1:1037857498957:web:f06a3c9c70ad8c8de43904"
};
export default firebaseConfig;
