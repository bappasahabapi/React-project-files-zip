# Thakurgaon HealthCare(Fully responsive)
Live Site Link: [Thakurgaon-Healthcare](https://thakurgaon-hospital.web.app/).

## In this project I use 
        - Firebase Authentation
        - Gooogle Varification, Email and Password
        - React Router functionality
        -Using Private Route For Appointments parts
        - Using Context API
        -Hosting in firebase

### Components
        -- Hooks 
        -- Firebase
        ---Context API

## Used 
        React Bootstrap
        React Router Dom
        Fake data json file
