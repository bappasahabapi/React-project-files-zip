import React from 'react';

const AddDoctor = () => {
    return (
        <div>
            <h3>Add A Doctor</h3>
        </div>
    );
};

export default AddDoctor;